package com.cg.bean;

public class CheckLoginEnum {  
	public enum LoginTypes{SUCCESS, FAIL, TEMPORARY,LOCK;}  
}
