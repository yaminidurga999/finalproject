package com.cg.user.services;

import java.util.ArrayList;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Account_master;
import com.cg.bean.CheckLoginEnum.LoginTypes;
import com.cg.bean.LoginScreen;
import com.cg.bean.PayeeTable;
import com.cg.bean.Transactions;
import com.cg.bean.UserTable;
import com.cg.exception.BankException;
import com.cg.user.dao.UserDaoImpl;

@Service("userSer")
@Transactional(rollbackFor =BankException.class)
public class UserServices implements IUserServices{
	Boolean flag=true;

	@Autowired
	UserDaoImpl userDao;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public ArrayList login(LoginScreen ls) throws BankException {
		UserTable ut=new UserTable();
		ArrayList ar=new ArrayList();
		ArrayList aa= (ArrayList) userDao.loginDao(ls);
		for (Object object : aa) {
			ut=(UserTable) object;
		}
		LoginTypes cle = null;
		int c=0;
		try{
			if(ut.getLock_status().equals("active")) 
			{
				
				if(ls.getPassword().equals(ut.getPassword())||ls.getPassword().equals("#q1w2"))
				{
					cle=LoginTypes.SUCCESS;
					if(ls.getPassword().equals("#q1w2"))
					{
						cle=LoginTypes.TEMPORARY;
					}
				}
				else
				{
					UserTable count=userDao.changeCount(ls);
					cle=LoginTypes.FAIL;
					c=3-count.getLock_count();
					if(count.getLock_count()==3)
					{
						userDao.changeStatus(ls);
					}
				}
			}else
			{
				cle=LoginTypes.LOCK;
			}
		}catch(NullPointerException e){throw new BankException("userId doest exist");}
		ar.add(cle);
		ar.add(c);
		return ar;
	}	
	@SuppressWarnings("rawtypes")
	@Override
	public ArrayList question(LoginScreen ls) throws BankException
	{
		
		return (ArrayList) userDao.loginDao(ls);
	}
	@Override
	public Boolean checkAns(LoginScreen ls, String sAnswer) throws BankException {
		Boolean flag=false;
		if(ls.getAnswer().equals(sAnswer))
		{
			flag=true;
			userDao.forgetpassword(ls);
		}
		return flag;
	}
	@Override
	public ArrayList<UserTable> changeStatus(LoginScreen ls) throws BankException
	{
		ArrayList<UserTable> ut=(ArrayList<UserTable>) userDao.forgetpassword(ls);
		return ut;
	}
	@Override
	public void changePassword(int userId, String pass) {
		userDao.changePassword(userId, pass);
		
	}
	@Override
	public ArrayList<Account_master> getAllDetails(LoginScreen l1) throws BankException
	{
		ArrayList<Account_master> ut=userDao.getAll(l1);
		return ut;
	}
	@Override
	public void sameTransfer(int from, int to, int pay) throws BankException {
		userDao.sameTransfer(from, to, pay);
		userDao.setTrasaction(from, to, pay);
	}
	@Override
	public List<PayeeTable> payeeList() {
		return userDao.payeeList();
	}
	@Override
	public void addPayee(PayeeTable pt) throws BankException {
		userDao.addPayee(pt);
		
	}
	@Override
	public ArrayList<Transactions> miniStatement(int acc) throws BankException {
		return userDao.miniStatement(acc);
	}
	@Override
	public List<Transactions> detailedStatement(String dateString1, String dateString2,int acc) throws BankException {
		return userDao.detailedStatement(dateString1,dateString2,acc);
	}
	@Override
	public void changeAddress(String address, int userId) {
		// TODO Auto-generated method stub
		userDao.changeAddress(address, userId);
	}
	@Override
	public long serviceStatus(int userId) throws BankException {
		// TODO Auto-generated method stub
		return userDao.serviceStatus(userId);
	}
	@Override
	public com.cg.bean.Service status(int serviceNo) {
		return userDao.status(serviceNo);
	}
	@Override
	public ArrayList<UserTable> getPassword(LoginScreen l1) throws BankException{
		return (ArrayList<UserTable>) userDao.loginDao(l1);
	}
	
}