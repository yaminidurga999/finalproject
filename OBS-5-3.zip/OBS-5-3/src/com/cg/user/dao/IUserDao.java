package com.cg.user.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Account_master;
import com.cg.bean.LoginScreen;
import com.cg.bean.PayeeTable;
import com.cg.bean.Service;
import com.cg.bean.Transactions;
import com.cg.bean.UserTable;
import com.cg.exception.BankException;


public interface IUserDao {
	public List<UserTable> loginDao(LoginScreen l1) throws BankException;
	public UserTable changeCount(LoginScreen ls) throws BankException;
	void changeStatus(LoginScreen ls) throws BankException;
	List<UserTable> forgetpassword(LoginScreen ls) throws BankException;
	void changePassword(int userId, String pass);
	ArrayList<Account_master> getAll(LoginScreen l1);
	void sameTransfer(int from, int to, int pay) throws BankException;
	List<PayeeTable> payeeList();
	void addPayee(PayeeTable pt) throws BankException;
	ArrayList<Transactions> miniStatement(int accountId) throws BankException;

	List<Transactions> detailedStatement(String dateString1, String dateString2, int acc) throws BankException;
	void changeAddress(String address, int userId);
	long serviceStatus(int userId) throws BankException;
	Service status(int serviceNo);
	void setTrasaction(int from, int to, int pay);
}
